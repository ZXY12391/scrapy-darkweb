#selenium不能用大概率是chrome driver 的版本问题
1.cabyc是长安不夜城的爬虫，用的是登陆后获取的Authorization，但Authorization每天都在変，采用javascript动态加载，获取的页面无HTML信息，因此访问JSON数据的API：http://cabyceogpsji73sske5nvo45mdrkbz4m3qd3iommf3zaaa6izg3j2cqd.onion
<<<<<<< HEAD
#验证交易密码：Zheshianwang123*
=======
#验证交易密码：
用户名：wenyan
密码；1234Awxmhh*
>>>>>>> 75f52e34b3859925b044af1d9c59e3eaa650370a
2.zwaww是暗网中文交易市场的爬虫，该网站每次登陆，刷新，点击后的URL都不一样，所以翻页按照正常逻辑会出现无限循环问题，登陆采用selenium，不用担心cookie问题：http://mxxxxxxxs4uqwd6cylditj7rh7zaz2clh7ofgik2z5jpeq5ixn4ziayd.onion
3.zwaw是暗网中文交易市场的爬虫，用的是获取到的cookie，但该网站的cookie每天都不一样，而且登陆页面的URL也经常更换。
4.Darkfox主要是一家信用卡商店。市场上可能有最大范围的被盗信用卡，带有用于在线购买的 stvc 代码。darkfox上的所有卡都有额外的信息，例如dob，ssn。出售卡的供应商需要支付 500 美元或更多的押金，因此如果卡不起作用，您可以随时上诉。今天，在darkfox上，您可以找到来自世界各地的信用卡，包括美国和欧洲，价格从5美元到100美元不等。darkfox上最受欢迎的信用卡供应商是：cheapboost，trebol，UniCC。
在购买之前，请仔细检查其他客户的评分和评论。
与大多数暗网市场一样，另一个受欢迎的商品类别是精神药物。大多数卖家运送到美国或世界各地。
黑狐市场的介绍：https://darkcatalog.com/darkfox-market/
用户名：wenyan
密码：darkfoxpass
PIN：haha
从 2023 年 2 月 20 日起，市场部分仅向余额达到或超过 50 美元的用户开放。  带来不便敬请谅解。
5.https://torrezmarkets.com/
用户名：wenyan,torrezhaha,
密码：torrezpass,torrezhaha,
PIN：torrez
cookie=PHPSESSID=0riq2kbugjo3c7scd65ocnrs2i; pc_333f7gpuishjximodvynnoisxujicgwaetzywgkxoxuje5ph3qyqjuid_onion__XSRF-TOKEN=eyJpdiI6Im1yZExZQXFSMkV3cmFpNUZBNnZpMFE9PSIsInZhbHVlIjoibzFPMlEwVW8zQ3loNUViUENLY3NDeTByc3phZnI4NHBEV3FySUhNR0pvSlVnXC8yY3JXa3dFVDQyYnB6aGRXKzVUUEw1SlFVMlNSQXZHSXBsK2k3SHY2VFNrTHp1THBnM0FTUUdRWXFGT2YyVjdSTGpZeUJqNXFIcWF3dndRK003IiwibWFjIjoiMzg4ZGQ4NzJjNmIwNTk3MTAwYWNkNDg2NTAyMTQ4YTk3ZGY5MDk2OThlMDA5MjYwNzcwOGU3Zjc3ZDA0YWJjMSJ9; pc_333f7gpuishjximodvynnoisxujicgwaetzywgkxoxuje5ph3qyqjuid_onion__hr4ujvby8ds459og4kzcpbzwjdj_session=eyJpdiI6Imw4Q3RPV0JyVHM4VmlJZGswNW45elE9PSIsInZhbHVlIjoibkp3MmJ3bHpra3ZVSytNQTh0cklWN2pjNzZXRVBKSis5RkRobzRpRWRObFJrU1pBdXdIV1ZSbzZOUHE5elFPWG13K3pPV0RXNE96SWpOdCttSCt3OUV3elg1WTZkb05uenVNbktaTW9yMDAzU0lwbzFwK0pXXC9tSE56dUJ4MmhNIiwibWFjIjoiODBjZDk3ZjBlYThkYzNmOWE5NTA4NGE5OWM1ZTcyZTJhNjlkMThmZDBhZmFjMjVhZGMxZDRmNDU2MWYxODcyMSJ9
6.自由国度论坛：
http://freedxxxrbrtxigoiyf333cradalwequhwocpv5wime7cxkrsk2bidqd.onion/index.php?m=u&c=login
用户名：wenyan
密码：freecitypass
7.复仇女神市场
介绍：https://nemesismarket.net/
8.ASAP
http://asap4g7boedkl3fxbnf2unnnr6kpxnwoewzw4vakaxiuzfdo5xpmy6ad.onion/
介绍：https://livedarknet.com/p/the-best-deep-web-markets-for-2022/
用户名：wenyan
密码：asappass
pin:123456
9.Bohemia
http://6rdk3rjnecd4qaazmupavufxuge3j2ug667tgrn4r6mkkjz4srt456yd.onion/member?action=register
密码：Bohemiapass1
10.KINGDOMPASS
密码：kingdompass
pin:123456
username:wenyanhaha   
phrase:ZXCV
② 用户名：kingdomhaha 密码：kingdompass
11.MGM GRAND
用户：wenyanMGM
密码：mgmpassword
pin:123456
https://darkcatalog.com/mgm-grand-market/
助记词：slightly trace further matter drove heaven wound cover sharp lung skip whatever clear joke touch


